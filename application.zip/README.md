## CodeIgniter Login

### Features
- Telah terintegrasi dengan Template AdminLTE-2.4.3
- Multi user / multi login
- Status untuk user yang aktif dan tidak aktif
- Animasi saat password salah, akun tidak terdaftar, dan akun tidak aktif
- Menggunakan keamanan hash untuk password
- Manajemen layout untuk template sehingga lebih tertata dan rapi
- Konfigurasi favicon, logo, dan informasi website dinamis
- Penambahan MY_Controller untuk session cek login di setiap controller
  
### User Login
- E-mail    : admin@mail.com (administrator)
- E-mail    : member@mail.com (member)
- Password  : password

### More
- Github https://github.com/susantokun
- Instagram https://www.instagram.com/susantokun
- Youtube https://www.youtube.com/susantokun
- Blog https://www.susantokun.com
- Info https://info.susantokun.com
- Demo https://demo.susantokun.com
- Paypal https://www.paypal.me/susantokun
- Email admin@susantokun.com
